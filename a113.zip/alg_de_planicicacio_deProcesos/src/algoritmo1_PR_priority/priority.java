package algoritmo1_PR_priority;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class priority {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        int n = 5; // Número de procesos
        ArrayList<int[]> procesos = new ArrayList<>();
        ArrayList<double[]> resultados = new ArrayList<>(); // Para almacenar los valores de P e I

        // Leer datos de los procesos
        for (int i = 0; i < n; i++) {
            int[] proceso = new int[8]; // Crear espacio para cada proceso
            proceso[0] = i; // Número de proceso
            System.out.print("Ingrese el tiempo de llegada para P" + i + ": ");
            proceso[1] = scanner.nextInt();
            System.out.print("Ingrese el tiempo de ráfaga para P" + i + ": ");
            proceso[2] = scanner.nextInt();
            System.out.print("Ingrese la prioridad para P" + i + ": ");
            proceso[3] = scanner.nextInt();
            procesos.add(proceso);
        }

        // Inicializar variables
        int tiempoActual = 0;
        ArrayList<int[]> terminados = new ArrayList<>();
        double sumaTcpu = 0, sumaTini = 0, sumaTfin = 0;   // Para promedios de Tcpu, Tini y Tfin
        double sumaT = 0, sumaE = 0, sumaP = 0, sumaI = 0; // Acumuladores para promedios

        // Planificación basada en el diagrama de Gantt
        while (!procesos.isEmpty()) {
            // Filtrar procesos disponibles en el tiempo actual
            ArrayList<int[]> disponibles = new ArrayList<>();
            for (int i = 0; i < procesos.size(); i++) {
            	int[] proceso = procesos.get(i);
                if (proceso[1] <= tiempoActual) {
                    disponibles.add(proceso);
                }
            }

            // Si no hay procesos disponibles, avanzar al próximo tiempo de llegada
            if (disponibles.size() == 0) { // Si no hay procesos disponibles
                int minimoTiempoLlegada = Integer.MAX_VALUE; // Valor inicial muy grande
                for (int i = 0; i < procesos.size(); i++) {
                    int tiempoLlegada = procesos.get(i)[1]; // Obtener T_ll del proceso
                    if (tiempoLlegada < minimoTiempoLlegada) {
                        minimoTiempoLlegada = tiempoLlegada; // Actualizar el mínimo
                    }
                }
                // Actualizar tiempoActual al menor tiempo de llegada encontrado
                if (minimoTiempoLlegada != Integer.MAX_VALUE) {
                    tiempoActual = minimoTiempoLlegada;
                }
                continue;
            }

            // Seleccionar el proceso con mayor prioridad (menor valor de PR)
            disponibles.sort(Comparator.comparingInt(p -> p[3]));
            int[] procesoSeleccionado = disponibles.get(0);
            procesos.remove(procesoSeleccionado);

            // Asignar tiempos al proceso seleccionado
            procesoSeleccionado[4] = Math.max(tiempoActual, procesoSeleccionado[1]); // Tiempo de inicio
            procesoSeleccionado[5] = procesoSeleccionado[4] + procesoSeleccionado[2]; // Tiempo de finalización
            procesoSeleccionado[6] = procesoSeleccionado[5] - procesoSeleccionado[1]; // Tiempo de servicio
            procesoSeleccionado[7] = procesoSeleccionado[6] - procesoSeleccionado[2]; // Tiempo de espera

            // Calcular valores decimales para P e I
            double penalizacion = (double) procesoSeleccionado[6] / procesoSeleccionado[2]; // Penalización
            double respuesta = (double) procesoSeleccionado[2] / procesoSeleccionado[6];   // Respuesta
            resultados.add(new double[]{penalizacion, respuesta});
            
         // Actualizar acumuladores
            sumaTcpu += procesoSeleccionado[2]; // Acumular Tcpu
            sumaTini += procesoSeleccionado[4]; // Acumular Tini
            sumaTfin += procesoSeleccionado[5]; // Acumular Tfin
            sumaT += procesoSeleccionado[6];
            sumaE += procesoSeleccionado[7];
            sumaP += penalizacion;
            sumaI += respuesta;

            // Actualizar tiempo actual y agregar a terminados
            tiempoActual = procesoSeleccionado[5];
            terminados.add(procesoSeleccionado);
        }

        // Mostrar resultados
        System.out.println("Prc    Tll  Tcpu  Pr   Tini    Tfin   T    E    P      I");
        for (int i = 0; i < terminados.size(); i++) {
            int[] proceso = terminados.get(i);
            double[] resultado = resultados.get(i);
            System.out.printf("%3d %5d %5d %4d %6d %5d %5d %5d %6.2f %5.2f\n",
                    proceso[0], proceso[1], proceso[2], proceso[3],
                    proceso[4], proceso[5], proceso[6], proceso[7],
                    resultado[0], resultado[1]);
        }
     // Calcular promedios
        double promedioTcpu = sumaTcpu / n;
        double promedioTini = sumaTini / n;
        double promedioTfin = sumaTfin / n;
        double promedioT = sumaT / n;
        double promedioE = sumaE / n;
        double promedioP = sumaP / n;
        double promedioI = sumaI / n;
        
     // Mostrar promedios
        System.out.println("\nPromedios:");
        System.out.printf("Tcpu: %.2f, Tini: %.2f, Tfin: %.2f\n", promedioTcpu, promedioTini, promedioTfin);
        System.out.printf("T: %.2f, E: %.2f, P: %.2f, I: %.2f\n", promedioT, promedioE, promedioP, promedioI);
    }
}