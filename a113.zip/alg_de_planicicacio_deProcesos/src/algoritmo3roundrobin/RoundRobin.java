package algoritmo3roundrobin;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

class Proceso {
    String nombre;
    int tiempoLlegada;
    int tiempoRafaga;
    int tiempoRestante;
    int tiempoInicio;
    int tiempoFinal;
    int tiempoEspera;
    int tiempoInactividad;

    Proceso(String nombre, int tiempoLlegada, int tiempoRafaga) {
        this.nombre = nombre;
        this.tiempoLlegada = tiempoLlegada;
        this.tiempoRafaga = tiempoRafaga;
        this.tiempoRestante = tiempoRafaga;
    }
}

public class RoundRobin {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el quantum: ");
        int quantum = scanner.nextInt();

        System.out.print("Ingrese el número de procesos: ");
        int numProcesos = scanner.nextInt();

        Proceso[] procesos = new Proceso[numProcesos];
        for (int i = 0; i < numProcesos; i++) {
            System.out.print("Ingrese el nombre del proceso: ");
            String nombre = scanner.next();
            System.out.print("Ingrese el tiempo de llegada del proceso: ");
            int tiempoLlegada = scanner.nextInt();
            System.out.print("Ingrese el tiempo de ráfaga del proceso: ");
            int tiempoRafaga = scanner.nextInt();
            procesos[i] = new Proceso(nombre, tiempoLlegada, tiempoRafaga);
        }

        Queue<Proceso> cola = new LinkedList<>();
        int tiempoActual = 0;
        int procesosTerminados = 0;

        while (procesosTerminados < numProcesos) {
            for (Proceso proceso : procesos) {
                if (proceso.tiempoLlegada <= tiempoActual && proceso.tiempoRestante > 0 && !cola.contains(proceso)) {
                    cola.add(proceso);
                }
            }

            if (!cola.isEmpty()) {
                Proceso procesoActual = cola.poll();
                if (procesoActual.tiempoRestante == procesoActual.tiempoRafaga) {
                    procesoActual.tiempoInicio = tiempoActual;
                }

                int tiempoEjecucion = Math.min(quantum, procesoActual.tiempoRestante);
                procesoActual.tiempoRestante -= tiempoEjecucion;
                tiempoActual += tiempoEjecucion;

                if (procesoActual.tiempoRestante == 0) {
                    procesoActual.tiempoFinal = tiempoActual;
                    procesosTerminados++;
                } else {
                    cola.add(procesoActual);
                }

                // Actualizar los tiempos de espera y inactividad
                for (Proceso p : procesos) {
                    if (p != procesoActual && p.tiempoLlegada <= tiempoActual && p.tiempoRestante > 0) {
                        p.tiempoEspera += tiempoEjecucion;
                    }
                }
            } else {
                tiempoActual++;
            }
        }

        System.out.println("\nResultados:");
        for (Proceso proceso : procesos) {
            System.out.println("Proceso " + proceso.nombre + ": ");
            System.out.println("Tiempo de Llegada: " + proceso.tiempoLlegada);
            System.out.println("Tiempo de Ráfaga: " + proceso.tiempoRafaga);
            System.out.println("Tiempo de Inicio: " + proceso.tiempoInicio);
            System.out.println("Tiempo de Finalización: " + proceso.tiempoFinal);
            System.out.println("Tiempo de Espera: " + proceso.tiempoEspera);
            System.out.println("Tiempo de Inactividad: " + (proceso.tiempoInicio - proceso.tiempoLlegada));
            System.out.println();
        }
    }
}
