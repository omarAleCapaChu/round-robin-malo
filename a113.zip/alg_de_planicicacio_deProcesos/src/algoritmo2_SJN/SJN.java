package algoritmo2_SJN;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class SJN {

	public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
	        int n = 5; // Número de procesos
	        ArrayList<int[]> procesos = new ArrayList<>();

	        // Leer datos de los procesos
	        for (int i = 0; i < n; i++) {
	            int[] proceso = new int[8]; // Crear espacio para cada proceso
	            proceso[0] = i; // Número de proceso
	            System.out.print("Ingrese el tiempo de llegada para P" + i + ": ");
	            proceso[1] = scanner.nextInt();
	            System.out.print("Ingrese el tiempo de ráfaga para P" + i + ": ");
	            proceso[2] = scanner.nextInt();
	            procesos.add(proceso);
	        }

	        // Inicializar variables
	        int tiempoActual = 0;
	        ArrayList<int[]> terminados = new ArrayList<>();
	        double sumaTcpu = 0, sumaTini = 0, sumaTfin = 0;   // Para promedios de Tcpu, Tini y Tfin
	        double sumaT = 0, sumaE = 0, sumaP = 0, sumaI = 0;

	        // Planificación basada en SJN
	        while (!procesos.isEmpty()) {
	        	// Filtrar procesos disponibles en el tiempo actual
	            ArrayList<int[]> disponibles = new ArrayList<>();
	            for (int i = 0; i < procesos.size(); i++) {
	            	int[] proceso = procesos.get(i);
	                if (proceso[1] <= tiempoActual) {
	                    disponibles.add(proceso);
	                }
	            }

	            // Si no hay procesos disponibles, avanzar al próximo tiempo de llegada
	         // Si no hay procesos disponibles, avanzar al próximo tiempo de llegada
	            if (disponibles.size() == 0) { // Si no hay procesos disponibles
	                int minimoTiempoLlegada = Integer.MAX_VALUE; // Valor inicial muy grande
	                for (int i = 0; i < procesos.size(); i++) {
	                    int tiempoLlegada = procesos.get(i)[1]; // Obtener T_ll del proceso
	                    if (tiempoLlegada < minimoTiempoLlegada) {
	                        minimoTiempoLlegada = tiempoLlegada; // Actualizar el mínimo
	                    }
	                }
	                // Actualizar tiempoActual al menor tiempo de llegada encontrado
	                if (minimoTiempoLlegada != Integer.MAX_VALUE) {
	                    tiempoActual = minimoTiempoLlegada;
	                }
	                continue;
	            }

	            // Seleccionar el proceso con el menor tiempo de ráfaga (Tcpu)
	            disponibles.sort(Comparator.comparingInt(p -> p[2]));
	            int[] procesoSeleccionado = disponibles.get(0);
	            procesos.remove(procesoSeleccionado);

	            // Asignar tiempos al proceso seleccionado
	            procesoSeleccionado[3] = Math.max(tiempoActual, procesoSeleccionado[1]); // Tiempo de inicio (Tini)
	            procesoSeleccionado[4] = procesoSeleccionado[3] + procesoSeleccionado[2]; // Tiempo de finalización (Tfin)
	            procesoSeleccionado[5] = procesoSeleccionado[4] - procesoSeleccionado[1]; // Tiempo de servicio (T)
	            procesoSeleccionado[6] = procesoSeleccionado[5] - procesoSeleccionado[2]; // Tiempo de espera (E)
	            double penalizacion = (double) procesoSeleccionado[5] / procesoSeleccionado[2]; // Penalización (P)
	            double respuesta = (double) procesoSeleccionado[2] / procesoSeleccionado[5];    // Respuesta (I)

	            // Acumular valores para promedios
	            sumaTcpu += procesoSeleccionado[2]; // Acumular Tcpu
	            sumaTini += procesoSeleccionado[3]; // Acumular Tini
	            sumaTfin += procesoSeleccionado[4]; // Acumular Tfin
	            sumaT += procesoSeleccionado[5];
	            sumaE += procesoSeleccionado[6];
	            sumaP += penalizacion;
	            sumaI += respuesta;

	            // Actualizar tiempo actual y agregar a terminados
	            tiempoActual = procesoSeleccionado[4];
	            terminados.add(procesoSeleccionado);
	        }

	        // Mostrar resultados
	        System.out.println("Prc    Tll  Tcpu   Tini  Tfin   T    E    P      I");
	        for (int[] proceso : terminados) {
	            System.out.printf("%3d %5d %5d %5d %5d %5d %5d %6.2f %5.2f\n",
	                    proceso[0], proceso[1], proceso[2], proceso[3],
	                    proceso[4], proceso[5], proceso[6],
	                    (double) proceso[5] / proceso[2], // Penalización (P)
	                    (double) proceso[2] / proceso[5]); // Respuesta (I)
	        }

	        // Calcular promedios
	        double promedioTcpu = sumaTcpu / n;
	        double promedioTini = sumaTini / n;
	        double promedioTfin = sumaTfin / n;
	        double promedioT = sumaT / n;
	        double promedioE = sumaE / n;
	        double promedioP = sumaP / n;
	        double promedioI = sumaI / n;

	        // Mostrar promedios
	        System.out.println("\nPromedios:");
	        System.out.printf("Tcpu: %.2f, Tini: %.2f, Tfin: %.2f, T: %.2f, E: %.2f, P: %.2f, I: %.2f\n", promedioTcpu, promedioTini, promedioTfin,promedioT, promedioE, promedioP, promedioI);

	        scanner.close();
	    }
	}