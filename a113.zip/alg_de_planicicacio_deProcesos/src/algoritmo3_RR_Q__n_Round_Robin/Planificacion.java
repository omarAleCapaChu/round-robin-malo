package algoritmo3_RR_Q__n_Round_Robin;

import java.util.*;

import algoritmo3roundrobin.Proceso;

class Proceso {
    int id, tiempoLlegada, tiempoRafaga;
    int tiempoInicio, tiempoFinal, tiempoEspera, tiempoServicio;
    double proporcionPenalizacion, proporcionRespuesta;

    public Proceso(int id, int tiempoLlegada, int tiempoRafaga) {
        this.id = id;
        this.tiempoLlegada = tiempoLlegada;
        this.tiempoRafaga = tiempoRafaga;
    }
}

public class Planificacion {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el quantum: ");
        int quantum = scanner.nextInt();

        System.out.print("Ingrese el número de procesos: ");
        int n = scanner.nextInt();

        List<Proceso> procesos = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            System.out.print("Ingrese el tiempo de llegada del proceso " + (i + 1) + ": ");
            int tiempoLlegada = scanner.nextInt();
            System.out.print("Ingrese el tiempo de ráfaga del proceso " + (i + 1) + ": ");
            int tiempoRafaga = scanner.nextInt();
            procesos.add(new Proceso(i + 1, tiempoLlegada, tiempoRafaga));
        }

        int tiempoActual = 0;
        Queue<Proceso> cola = new LinkedList<>();
        List<Proceso> completados = new ArrayList<>();
        int[] rafagasRestantes = new int[n];

        for (int i = 0; i < n; i++) {
            rafagasRestantes[i] = procesos.get(i).tiempoRafaga;
        }

        while (completados.size() < n) {
            for (Proceso proceso : procesos) {
                if (proceso.tiempoLlegada <= tiempoActual && !cola.contains(proceso) && !completados.contains(proceso)) {
                    cola.add(proceso);
                }
            }

            if (!cola.isEmpty()) {
                Proceso actual = cola.poll();
                if (actual.tiempoInicio == 0) {
                    actual.tiempoInicio = tiempoActual;
                }
                int tiempoEjecucion = Math.min(quantum, rafagasRestantes[actual.id - 1]);
                rafagasRestantes[actual.id - 1] -= tiempoEjecucion;
                tiempoActual += tiempoEjecucion;

                if (rafagasRestantes[actual.id - 1] == 0) {
                    actual.tiempoFinal = tiempoActual;
                    actual.tiempoServicio = actual.tiempoFinal - actual.tiempoLlegada;
                    actual.tiempoEspera = actual.tiempoServicio - actual.tiempoRafaga;
                    actual.proporcionPenalizacion = (double) actual.tiempoServicio / actual.tiempoRafaga;
                    actual.proporcionRespuesta = (double) actual.tiempoInicio / actual.tiempoLlegada;
                    completados.add(actual);
                } else {
                    cola.add(actual);
                }
            } else {
                tiempoActual++;
            }
        }

        double totalEspera = 0, totalServicio = 0, totalPenalizacion = 0, totalRespuesta = 0;

        System.out.println("\nResultados:");
        System.out.printf("%-10s%-15s%-15s%-15s%-15s%-15s%-15s\n", "Proceso", "Inicio", "Final", "Servicio", "Espera", "Penalización", "Respuesta");
        for (Proceso proceso : completados) {
            System.out.printf("%-10d%-15d%-15d%-15d%-15d%-15.2f%-15.2f\n",
                    proceso.id, proceso.tiempoInicio, proceso.tiempoFinal, proceso.tiempoServicio,
                    proceso.tiempoEspera, proceso.proporcionPenalizacion, proceso.proporcionRespuesta);
            totalEspera += proceso.tiempoEspera;
            totalServicio += proceso.tiempoServicio;
            totalPenalizacion += proceso.proporcionPenalizacion;
            totalRespuesta += proceso.proporcionRespuesta;
        }

        System.out.println("\nPromedios:");
        System.out.printf("Espera: %.2f, Servicio: %.2f, Penalización: %.2f, Respuesta: %.2f\n",
                totalEspera / n, totalServicio / n, totalPenalizacion / n, totalRespuesta / n);

        scanner.close();
    }
}