package algoritmo3_RR_Q__n_Round_Robin;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class RR_Q_n {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el número de procesos: ");
        int n = scanner.nextInt();
        System.out.print("Ingrese el quantum (Q): ");
        int quantum = scanner.nextInt();

        // Lista de procesos, cada uno tiene: id, tiempo de llegada, tiempo de ráfaga
        ArrayList<int[]> procesos = new ArrayList<>();
        Queue<int[]> cola = new LinkedList<>();

        // Leer los datos de los procesos
        for (int i = 0; i < n; i++) {
            int[] proceso = new int[9]; // id, Tll, Tcpu, Tini, Tfin, T, E, P, I
            proceso[0] = i; // id del proceso
            System.out.print("Ingrese el tiempo de llegada para P" + i + ": ");
            proceso[1] = scanner.nextInt(); // Tiempo de llegada
            System.out.print("Ingrese el tiempo de ráfaga para P" + i + ": ");
            proceso[2] = scanner.nextInt(); // Tiempo de ráfaga
            proceso[8] = proceso[2]; // Guardar el tiempo de ráfaga original
            proceso[3] = -1; // Inicializar Tini con un valor inválido
            procesos.add(proceso);
        }

        // Inicializar variables
        int tiempoActual = 0; // El tiempo actual en el que se va a ejecutar el algoritmo
        ArrayList<int[]> terminados = new ArrayList<>();
        double sumaT = 0, sumaE = 0, sumaP = 0, sumaI = 0;

        // Cola de procesos listos
        while (!procesos.isEmpty() || !cola.isEmpty()) {
            // Añadir los procesos que llegan al tiempo actual a la cola
            for (int i = 0; i < procesos.size(); i++) {
                if (procesos.get(i)[1] <= tiempoActual) {
                    cola.add(procesos.get(i));
                    procesos.remove(i);
                    i--; // Ajustar el índice tras eliminación
                }
            }

            // Si la cola está vacía, avanzar al próximo tiempo de llegada
            if (cola.isEmpty()) {
                tiempoActual = procesos.stream().mapToInt(p -> p[1]).min().orElse(tiempoActual);
                continue;
            }

            // Seleccionar el primer proceso de la cola
            int[] procesoActual = cola.poll();

            // Asignar Tini si es la primera vez que se ejecuta
            if (procesoActual[3] == -1) { // Tini no asignado
                procesoActual[3] = tiempoActual; // El Tini es igual al tiempo actual cuando empieza a ejecutarse
            }

            // Calcular cuánto tiempo ejecuta en este quantum
            int tiempoEjecutado = Math.min(procesoActual[2], quantum);

            // Actualizar tiempos
            tiempoActual += tiempoEjecutado; // Avanzamos el tiempo actual
            procesoActual[2] -= tiempoEjecutado; // Reducir tiempo de ráfaga restante

            // Si el proceso terminó
            if (procesoActual[2] == 0) {
                procesoActual[4] = tiempoActual; // Tfin = tiempo actual cuando termina
                procesoActual[5] = procesoActual[4] - procesoActual[1]; // T = Tfin - Tll
                procesoActual[6] = procesoActual[5] - procesoActual[8]; // E = T - Tcpu_original
                double penalizacion = (double) procesoActual[5] / procesoActual[8]; // P
                double respuesta = (double) procesoActual[8] / procesoActual[5]; // I

                // Actualizar acumuladores para promedios
                sumaT += procesoActual[5];
                sumaE += procesoActual[6];
                sumaP += penalizacion;
                sumaI += respuesta;

                // Agregar el proceso terminado a la lista
                terminados.add(procesoActual);
            } else {
                // Si el proceso no ha terminado, volver a ponerlo en la cola
                cola.add(procesoActual);
            }
        }

        // Mostrar los resultados
        System.out.println("Prc  Tll  Tcpu  Tini  Tfin   T    E    P    I");
        for (int[] proceso : terminados) {
            double penalizacion = (double) proceso[5] / proceso[8]; // P
            double respuesta = (double) proceso[8] / proceso[5];    // I
            System.out.printf("%3d %5d %5d %5d %5d %5d %5d %6.2f %5.2f\n",
                    proceso[0], proceso[1], proceso[8], proceso[3],
                    proceso[4], proceso[5], proceso[6],
                    penalizacion, respuesta);
        }

        // Calcular los promedios
        double promedioT = sumaT / n;
        double promedioE = sumaE / n;
        double promedioP = sumaP / n;
        double promedioI = sumaI / n;

        // Mostrar promedios
        System.out.println("\nPromedios:");
        System.out.printf("T: %.2f, E: %.2f, P: %.2f, I: %.2f\n", promedioT, promedioE, promedioP, promedioI);

        scanner.close();
    }
}
